package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    private WebDriver webDriver;

    public LoginPage(WebDriver webDriver) {
        this.webDriver = webDriver;
        PageFactory.initElements(webDriver, this);
    }

    @FindBy(name = "login")
    WebElement login;
    @FindBy(name = "password")
    WebElement password;

    void openPage() {
        webDriver.get("https://avic.ua/ua/sign-in");
    }

    void enterPhone() {
       login.sendKeys("0974354660");
    }

    void enterPass() {
     password.sendKeys("+380974354660");
    }

    boolean atPage() {
        if (webDriver.getCurrentUrl().equals("https://avic.ua/ua/sign-in"))
            return true;
        return false;
    }

    boolean login() {
        openPage();
        enterPass();
        enterPhone();
        webDriver.findElement(By.xpath("//button[contains(@class,'button-reset main-btn submit main-btn--green')]")).click();
        return webDriver.getCurrentUrl().equals("https://avic.ua/ua");
    }


}

