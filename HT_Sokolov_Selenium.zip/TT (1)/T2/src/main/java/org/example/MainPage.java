package org.example;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class MainPage {

    private WebDriver webDriver;

    public MainPage(WebDriver webDriver) {
        this.webDriver = webDriver;
        PageFactory.initElements(webDriver, this);
    }

    void openPage() {
        webDriver.get("https://demo.nopcommerce.com/");
    }

    @FindBy(xpath = "/html/body/div[6]/div[2]/ul[2]/li[1]/a")
    WebElement computers;
    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div[3]/div/div[2]/div[1]/div/div[1]/div/h2/a")
    WebElement deksptops;
    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div[3]/div/div[2]/div[2]/div[2]/div/div/div[2]/div/div[1]/a/img")
    WebElement page;

    public void doTest() {
        openPage();
        computers.click();
        deksptops.click();
        page.click();
    }

}
