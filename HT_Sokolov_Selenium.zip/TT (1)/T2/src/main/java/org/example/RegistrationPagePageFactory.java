package org.example;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class RegistrationPagePageFactory {
    private WebDriver webDriver;
    public RegistrationPagePageFactory(WebDriver webDriver) {
        this.webDriver = webDriver;
        PageFactory.initElements(webDriver,this);
    }

    @FindBy(name = "phone")
    WebElement phone;
    @FindBy(name = "email")
    WebElement email;
    @FindBy(name = "password")
    WebElement pass;
    @FindBy(xpath = "//input[@class='validate password_1 show-password']")
    WebElement pass2;
    @FindBy(xpath = "//button[contains(@class,'button-reset main-btn js_validate submit main-btn--green')]")
    WebElement buton;
    public boolean register() {
        webDriver.get("https://avic.ua/ua/sign-up");
        phone.sendKeys("0974354660");
//        email.sendKeys("+380974354660");
        pass.sendKeys("+380974354660");
        pass2.sendKeys("+380974354660");
        buton.click();
        //явное ожидание
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        WebElement element=(new WebDriverWait(webDriver,Duration.ofSeconds(10)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@class,'ttl js_title')]"))));
       return webDriver.findElement(By.xpath("//div[contains(@class,'ttl js_title')]")).isDisplayed();
    }

    boolean atPage(){
        if(webDriver.getTitle().equals("f"))
            return true;
        return false;
    }


}