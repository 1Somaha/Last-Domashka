package org.example;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import javax.print.DocFlavor;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

import java.net.MalformedURLException;
import java.net.URL;

public class FirstTest {

    public WebDriver driver;
    ChromeOptions chromeOptions = new ChromeOptions();

    public FirstTest() throws MalformedURLException {
    }

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/chromedriver.exe");
        driver = new ChromeDriver( chromeOptions);
    }



    @Test
    public void testSearch() {
        MainPage mainPage = new MainPage(driver);
        mainPage.doTest();
        driver.quit();

    }
}